

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php if($value == null ): ?>
            <?php echo e("no queue"); ?>

        
        <?php else: ?>
            
        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-12 mt-3" >
            <div class="card">
                <div class="card-body">
                    <?php echo e($value[$key]); ?>

                    <?php $__currentLoopData = $song; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($info->id == $data): ?>
                            <?php echo e($info->name); ?>

                            <?php echo e($info->artist); ?>

                            <?php echo e($info->length); ?>

                            <a href=<?php echo e("delete/" .$info->id); ?> class="btn btn-danger btn-sm"> Delete  <?php echo e($info->name); ?> out queue? </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
                
            </div>
         </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        <a href=<?php echo e("delete/"); ?> class="btn btn-danger btn-sm"> Delete all out queue </a> 
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jaar2\Jukebox\jukebox\resources\views//queues/index.blade.php ENDPATH**/ ?>