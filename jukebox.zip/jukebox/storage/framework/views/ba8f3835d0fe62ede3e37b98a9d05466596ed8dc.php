

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-12 mt-3" >
            <div class="card">
                <div class="card-body">
                    <?php $duration = 0;?>
                    <h2 class="card-title">Playlist name: <?php echo e($playlist->name); ?></h3>
                    <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-12 mt-3" >
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Song: <?php echo e($song[0]->name); ?></h5>
                                    <p class="card-text">artist: <?php echo e($song[0]->artist); ?></p>
                                    <p class="card-text">length: <?php echo e($song[0]->length); ?></p>
                                    <p class="hidetime" style="display: none"><?php echo e($duration += strtotime($song[0]->length)); ?></p>
                                    <a href=<?php echo e("delete/" .$song[0]->id . "/" . $playlist->id); ?> class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')"> Delete out <?php echo e($playlist->name); ?> </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <h5 id="time"> Duration: <?php echo e(date('H:i:s', $duration)); ?></h5>
                </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jaar2\Jukebox\jukebox\resources\views/playlists/details.blade.php ENDPATH**/ ?>