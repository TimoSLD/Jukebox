<?php $__env->startSection('content'); ?>
    
<div class="container">
    <div class="row">
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-2 mx-auto" >
            <div class="card">
                <div class="card-body">
                <h5 class="card-title"><?php echo e($genre->name); ?></h5>
                <a href="#" class="btn btn-primary">see all <?php echo e($genre->name); ?> songs</a>
                </div>
            </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jaar2\Jukebox\jukebox\resources\views/home.blade.php ENDPATH**/ ?>