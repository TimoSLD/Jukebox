
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">playlist Page</div>
  <div class="card-body">
      
      <form action="<?php echo e(url('playlists')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <label>Name</label></br>
        <input type="text" name="name" id="name" class="form-control"></br>
        
        <div style="display:none">
            <input type="text" id="user_id" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
        </div>
       
        <input type="submit" value="Save" class="btn btn-success"></br>
    </form>
  
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jaar2\Jukebox\jukebox\resources\views/playlists/create.blade.php ENDPATH**/ ?>