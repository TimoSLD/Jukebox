

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php $duration = 0;?>
            <?php if(Session::has('song')): ?>
                <?php $__currentLoopData = Session::get('song'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <?php echo e($item['id']); ?>

                        <?php echo e($item['name']); ?>

                        <?php echo e($item['length']); ?>

                        <p class="hidetime" style="display: none"><?php echo e($duration += strtotime($item->length)); ?></p>
                        <a href=<?php echo e("delete/" . $item['id']); ?> class="btn btn-danger btn-sm"> Delete  <?php echo e($item['name']); ?> out queue? </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
           
                <h5 id="time"> Duration: <?php echo e(date('H:i:s', $duration)); ?></h5>
             <a href=<?php echo e("delete/"); ?> class="btn btn-danger btn-sm"> Delete all out queue </a>
             <a href=<?php echo e("playlists/playlist_song/"); ?> class="btn btn-success btn-sm"> create playlist of queue </a> 
             
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jaar2\Jukebox\jukebox\resources\views/queues/index.blade.php ENDPATH**/ ?>